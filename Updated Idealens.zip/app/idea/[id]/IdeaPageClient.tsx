"use client";

import { useParams, useRouter } from "next/navigation";
import { useEffect, useMemo, useState, useCallback } from "react";
import { supabase } from "@/lib/supabaseClient";
import {
    LogoBar,
    Section,
    ChipRow,
    BulletRow,
    ScoringSlider,
    AISnapshot,
    CollapsibleSection,
    InnovationSignature
} from "./Components";
import {
    Sparkles,
    Rocket,
    ShieldCheck,
    Target,
    Zap,
    Settings,
    TrendingUp,
    AlertTriangle,
    Lightbulb,
    Mic2,
    Heart,
    Cpu,
    Coins,
    ChevronDown,
    Activity,
    CheckCircle2,
    XCircle,
    Info,
    Timer as TimerIcon,
    Play,
    Pause,
    RotateCcw
} from "lucide-react";

/**
 * Modern Presentation Timer Component
 */
function PresentationTimer({ teamId, isSubmitted, onTimeUpdate }: { teamId: string, isSubmitted: boolean, onTimeUpdate: (seconds: number) => void }) {
    const [seconds, setSeconds] = useState(0);
    const [isActive, setIsActive] = useState(false);

    useEffect(() => {
        const savedTime = localStorage.getItem(`timer_${teamId}`);
        if (savedTime) setSeconds(parseInt(savedTime, 10));

        // Auto-start timer on load if not submitted
        if (!isSubmitted) setIsActive(true);
    }, [teamId, isSubmitted]);

    useEffect(() => {
        let interval: any = null;
        if (isActive && !isSubmitted) {
            interval = setInterval(() => {
                setSeconds(prev => {
                    const next = prev + 1;
                    localStorage.setItem(`timer_${teamId}`, next.toString());
                    onTimeUpdate(next);
                    return next;
                });
            }, 1000);
        } else {
            clearInterval(interval);
        }
        return () => clearInterval(interval);
    }, [isActive, isSubmitted, teamId, onTimeUpdate]);

    const formatTime = (s: number) => {
        const mins = Math.floor(s / 60);
        const secs = s % 60;
        return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    };

    return (
        <div className="flex items-center gap-3 bg-white border border-slate-200 px-4 py-2 rounded-2xl shadow-sm">
            <div className="flex items-center gap-2 pr-3 border-r border-slate-100">
                <TimerIcon size={16} className={isActive ? "text-brand-accent animate-pulse" : "text-slate-400"} />
                <span className="text-sm font-black tabular-nums text-slate-900">{formatTime(seconds)}</span>
            </div>
            {!isSubmitted && (
                <div className="flex items-center gap-1">
                    <button
                        onClick={() => setIsActive(!isActive)}
                        className="p-1.5 hover:bg-slate-50 rounded-lg transition-colors text-slate-500"
                        title={isActive ? "Pause" : "Start"}
                    >
                        {isActive ? <Pause size={14} fill="currentColor" /> : <Play size={14} fill="currentColor" />}
                    </button>
                    <button
                        onClick={() => {
                            if (confirm("Reset timer?")) {
                                setSeconds(0);
                                localStorage.setItem(`timer_${teamId}`, "0");
                                onTimeUpdate(0);
                            }
                        }}
                        className="p-1.5 hover:bg-slate-50 rounded-lg transition-colors text-slate-400"
                        title="Reset"
                    >
                        <RotateCcw size={14} />
                    </button>
                </div>
            )}
        </div>
    );
}

type TeamRow = {
    team_id: string;
    team_name: string;
    problem_title: string | null;
    problem_statement: string | null;
    team_size: number | null;
    team_members: string | null;
    team_roles: string | null;
    contact_email: string | null;
    proposed_solution: string | null;
    target_users: string | null;
    innovation_highlights: string | null;
    tech_stack: string | null;
    market_readiness: string | null;
    execution_risk: string | null;
    pdf_upload: string | null;
    business_model: string | null;
    market_insight: string | null;
    department: string | null;
    risk_level?: 'Low' | 'Medium' | 'High';
};

type ResultRow = {
    team_id: string;
    summary: string | null;
    desirability_score: number | string | null;
    feasibility_score: number | string | null;
    viability_score: number | string | null;
    average_dfv_score: number | string | null;
    weighted_dfv?: number | string | null;
    insights: string | null;
    market_context_signal: string | null;
    execution_readiness_signal: string | null;
    transaction_details: any | null;
    created_at: string;
    market_readiness?: number | string | null;
    execution_risk?: number | string | null;
};

type JuryScoreRow = {
    idea_id: string;
    team_name: string;
    desirability_score: number | null;
    feasibility_score: number | null;
    viability_score: number | null;
};

export default function IdeaPageClient() {
    const params = useParams();
    const router = useRouter();

    const [ideaId, setIdeaId] = useState<string>("");
    const [loading, setLoading] = useState(true);
    const [team, setTeam] = useState<TeamRow | null>(null);
    const [result, setResult] = useState<ResultRow | null>(null);
    const [juryScores, setJuryScores] = useState<JuryScoreRow[]>([]);
    const [error, setError] = useState<string | null>(null);
    const [missingTableError, setMissingTableError] = useState(false);

    const [jury, setJury] = useState({
        desirability: "5",
        feasibility: "5",
        viability: "5",
        presentation: "5",
    });
    const [juryNotes, setJuryNotes] = useState("");
    const [juryName, setJuryName] = useState("");
    const [submitted, setSubmitted] = useState(false);
    const [showSignature, setShowSignature] = useState(false);
    const [submitting, setSubmitting] = useState(false);
    const [aiRevealed, setAiRevealed] = useState(false);
    const [evaluationTime, setEvaluationTime] = useState(0);
    const [searchQuery, setSearchQuery] = useState("");
    const [searchResults, setSearchResults] = useState<{ team_id: string, team_name: string }[]>([]);
    const [showSearchResults, setShowSearchResults] = useState(false);

    useEffect(() => {
        const extractId = () => {
            if (typeof window === "undefined") return "";
            const path = window.location.pathname;
            const segments = path.split('/').filter(Boolean);
            const ideaIdx = segments.indexOf('idea');
            const idFromPath = (ideaIdx !== -1 && segments[ideaIdx + 1]) ? segments[ideaIdx + 1] : "";
            const reserved = ['view', 'placeholder', 'fallback', 'index', 'loading', 'undefined', 'null'];
            if (idFromPath && !reserved.includes(idFromPath)) return idFromPath;
            const pId = params?.id as string;
            if (pId && !reserved.includes(pId)) return pId;
            return "";
        };

        const finalId = extractId();
        if (finalId) setIdeaId(finalId);
        else {
            let count = 0;
            const interval = setInterval(() => {
                count++;
                const retryId = extractId();
                if (retryId) {
                    setIdeaId(retryId);
                    clearInterval(interval);
                } else if (count > 25) {
                    setLoading(false);
                    if (typeof window !== "undefined" && (window.location.pathname.includes('placeholder') || window.location.pathname.includes('view'))) {
                        router.push('/');
                    }
                    clearInterval(interval);
                }
            }, 100);
            return () => clearInterval(interval);
        }
    }, [params, router]);

    const aiScores10 = useMemo(() => {
        const raw = result as any;
        const d = raw?.desirability_score ?? raw?.desirability ?? null;
        const f = raw?.feasibility_score ?? raw?.feasibility ?? null;
        const v = raw?.viability_score ?? raw?.viability ?? null;
        const avg = raw?.average_dfv_score ?? raw?.weighted_dfv ?? null;
        const mr = raw?.market_readiness ?? null;
        const er = raw?.execution_risk ?? null;

        const toDisplay = (x: any) => {
            if (x === null || x === undefined) return null;
            const n = typeof x === 'string' ? parseFloat(x) : x;
            return isNaN(n) ? null : Math.round(n * 10) / 10;
        };
        return {
            d: toDisplay(d),
            f: toDisplay(f),
            v: toDisplay(v),
            feasibility: toDisplay(f),
            viability: toDisplay(v),
            avg: toDisplay(avg),
            mr: toDisplay(mr),
            er: toDisplay(er)
        };
    }, [result]);

    const { weightedScore, alignment, innovationIndex, classification } = useMemo(() => {
        const d = Number(jury.desirability) || 0;
        const f = Number(jury.feasibility) || 0;
        const v = Number(jury.viability) || 0;
        const p = Number(jury.presentation) || 0;

        const ws = ((d * 0.3) + (f * 0.3) + (v * 0.3) + (p * 0.1)).toFixed(1);

        // Alignment Calculation
        const aiPts = [
            aiScores10.mr || 0,
            aiScores10.feasibility || aiScores10.er || 0,
            aiScores10.viability || 0,
            10 - (aiScores10.er || 0)
        ];
        const juryPts = [d, f, v, p];
        const dev = aiPts.reduce((acc, val, i) => acc + Math.abs(val - juryPts[i]), 0);
        const align = Math.max(0, Math.min(100, Math.round(100 - (dev * 2.5))));

        const idx = Math.round((Number(ws) * 8) + (align * 0.2));

        // Dynamic Classification (matched with Components logic)
        const getClassification = (score: number, align: number) => {
            if (score > 85 && align > 80) return "Disruptive Potential";
            if (score > 70 && align < 40) return "Market Driven";
            if (score < 40) return "High Risk";
            if (f > 8) return "Execution Strong";
            return "Balanced Innovation";
        };

        return {
            weightedScore: ws,
            alignment: align,
            innovationIndex: idx,
            classification: getClassification(idx, align)
        };
    }, [jury, aiScores10]);

    useEffect(() => {
        if (!ideaId) return;
        const run = async () => {
            setLoading(true);
            setError(null);
            const decodedIdentifier = decodeURIComponent(ideaId);
            let { data: teamData, error: teamError } = await supabase
                .from("idea_submissions")
                .select("*")
                .eq("team_name", decodedIdentifier)
                .maybeSingle();

            if (!teamData && !teamError) {
                const fallback = await supabase
                    .from("idea_submissions")
                    .select("*")
                    .eq("team_id", ideaId)
                    .maybeSingle();
                teamData = fallback.data as TeamRow;
                teamError = fallback.error;
            }

            if (teamError) {
                setError(`Teams fetch error: ${teamError.message}`);
                setLoading(false);
                return;
            }

            if (teamData) {
                setTeam(teamData as TeamRow);
                await refreshData(teamData as TeamRow, teamData.team_id);

                // Load saved notes and jury name from LocalStorage
                const savedNotes = localStorage.getItem(`notes_${teamData.team_id}`);
                if (savedNotes) setJuryNotes(savedNotes);
                const savedName = localStorage.getItem('ideaLensJuryName');
                if (savedName) setJuryName(savedName);
            }
            setLoading(false);
        };
        run();
    }, [ideaId]);

    // Auto-save notes and jury name
    useEffect(() => {
        if (team?.team_id && juryNotes) {
            localStorage.setItem(`notes_${team.team_id}`, juryNotes);
        }
    }, [juryNotes, team?.team_id]);

    useEffect(() => {
        if (juryName) {
            localStorage.setItem('ideaLensJuryName', juryName);
        }
    }, [juryName]);

    const refreshData = async (teamData: TeamRow, actualId: string) => {
        const tables = [
            { name: "ai_evaluations", cols: ["team_name", "team_id"], sort: "evaluated_at" },
            { name: "human_evaluations", cols: ["team_name", "idea_id"], sort: null }
        ];

        let finalResult: any = null;
        for (const table of tables) {
            for (const col of table.cols) {
                try {
                    let query = supabase.from(table.name).select("*");
                    const value = (col.includes("name") || col === "team") ? teamData.team_name : actualId;
                    if (col.includes("name") || col === "team") query = query.ilike(col, value.trim());
                    else query = query.eq(col, value);
                    if (table.sort) query = query.order(table.sort, { ascending: false });
                    const { data } = await query.limit(1).maybeSingle();
                    if (data && !finalResult) finalResult = { ...data };
                } catch (e) { }
            }
        }
        setResult(finalResult as ResultRow | null);

        // Calculate risk level from result
        if (teamData && finalResult) {
            const riskNum = Number(finalResult.execution_risk) || 5;
            let riskLabel: 'Low' | 'Medium' | 'High' = 'Medium';
            if (riskNum < 4) riskLabel = 'Low';
            else if (riskNum > 7) riskLabel = 'High';
            setTeam(prev => prev ? { ...prev, risk_level: riskLabel } : null);
        }

        if (teamData?.team_name) {
            await fetchJuryScores(teamData.team_name, actualId, finalResult !== null);
        }
    };

    const fetchJuryScores = async (teamName: string, teamId: string, hasAiResult: boolean = false) => {
        const { data, error } = await supabase
            .from("human_evaluations")
            .select("idea_id, team_name, desirability_score, feasibility_score, viability_score")
            .eq("idea_id", teamId);

        if (error) {
            if (error.code === '42P01') setMissingTableError(true);
        } else {
            const scores = data as JuryScoreRow[] || [];
            setJuryScores(scores);
            if (scores.length > 0) setSubmitted(true);
            if (scores.length > 0 && hasAiResult) setAiRevealed(true);
        }
    };

    const onSubmit = async () => {
        if (juryScores.length > 0) return setError("This team has already been evaluated.");
        if (!team?.team_name) return setError("Team data not loaded properly.");

        if (!juryName.trim()) return setError("Please enter your Jury Name before submitting.");

        setSubmitting(true);
        try {
            const { error: insertError } = await supabase.from("human_evaluations").insert([{
                team_name: team.team_name,
                idea_id: team.team_id,
                evaluator_id: juryName,
                desirability_score: Number(jury.desirability),
                feasibility_score: Number(jury.feasibility),
                viability_score: Number(jury.viability),
                evaluation_time: evaluationTime
            }]);

            if (insertError) throw insertError;
            setSubmitted(true);
            setShowSignature(true);
            await fetchJuryScores(team.team_name, team.team_id);
            // Clear notes on successful submission
            localStorage.removeItem(`notes_${team.team_id}`);
        } catch (e: any) {
            setError(e?.message || "Submit failed");
        } finally {
            setSubmitting(false);
        }
    };

    if (loading) {
        return (
            <div className="min-h-screen bg-slate-50 flex items-center justify-center">
                <div className="text-center space-y-4">
                    <div className="w-16 h-16 border-4 border-brand-accent border-t-transparent rounded-full animate-spin mx-auto"></div>
                    <div className="text-xl font-black text-slate-900 italic uppercase tracking-widest animate-pulse">Loading Idea...</div>
                </div>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-slate-50 font-sans text-slate-900 selection:bg-brand-accent/30 pb-20">

            <main className="w-full px-8 pt-2">
                {!team ? (
                    <div className="max-w-4xl mx-auto bg-white border border-slate-200 p-20 rounded-[3rem] text-center shadow-sm animate-premium">
                        <div className="text-2xl font-black text-slate-900 mb-2 uppercase tracking-tight italic">Intelligence Node Not Found</div>
                        <div className="text-slate-400 font-mono text-sm mb-8">Ref: {ideaId}</div>
                        <button onClick={() => router.push('/')} className="px-8 py-4 bg-slate-900 text-white rounded-2xl font-black uppercase italic tracking-widest hover:scale-105 transition-all">TERMINATE & RETURN</button>
                    </div>
                ) : (
                    <div className="animate-advanced-reveal">
                        <LogoBar />

                        {/* Navigation - Below PES Logo */}
                        <div className="mb-8">
                            <button onClick={() => router.push('/')} className="flex items-center gap-2 text-slate-400 hover:text-slate-900 transition-colors font-black text-[10px] uppercase tracking-[0.3em] group">
                                <span className="group-hover:-translate-x-1 transition-transform text-base relative -top-[1px]">←</span> Back
                            </button>
                        </div>

                        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-10 mb-12">
                            <div className="space-y-4">
                                <div className="flex items-center gap-3">
                                    <span className="px-3 py-1 bg-brand-accent/10 text-brand-accent rounded-full text-[10px] font-black uppercase tracking-widest border border-brand-accent/20">Team Evaluation</span>
                                    <div className="h-1 w-1 rounded-full bg-slate-300"></div>
                                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">ID: {team.team_id.slice(0, 8)}</span>
                                </div>
                                <h1 className="text-7xl font-black text-slate-900 tracking-tighter leading-none italic uppercase">
                                    {team.team_name}
                                </h1>
                                <div className="flex items-center gap-3 text-brand-blue/60 font-medium text-lg italic">
                                    <span>{team.department || "Innovation Group"}</span>
                                    <span>•</span>
                                    <span>{team.team_size || 5} Operatives</span>
                                </div>
                            </div>

                            {/* Presentation Timer Integration */}
                            <div className="flex flex-col items-end gap-3">
                                <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Presentation Timer</div>
                                <PresentationTimer
                                    teamId={team.team_id}
                                    isSubmitted={juryScores.length > 0}
                                    onTimeUpdate={(s) => setEvaluationTime(s)}
                                />
                            </div>
                        </div>

                        <InnovationSignature
                            isOpen={showSignature}
                            onClose={() => setShowSignature(false)}
                            data={{
                                index: innovationIndex,
                                classification: classification,
                                alignment,
                                time: evaluationTime,
                                strengths: (result as any)?.strengths || [],
                                risks: (result as any)?.risks || []
                            }}
                        />

                        <AISnapshot
                            scores={aiScores10}
                            insights={result?.summary || null}
                        />

                        <div className="grid grid-cols-1 gap-12">
                            {/* Main Content Spine (Full Width) */}
                            <div className="space-y-12">
                                <div className="border-b border-slate-100 pb-12">
                                    <div className="flex flex-wrap items-center gap-x-12 gap-y-4">
                                        <div className="flex flex-col min-w-[120px]">
                                            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Status</span>
                                            <div className="flex items-center gap-2">
                                                <div className={`h-2 w-2 rounded-full ${juryScores.length > 0 ? 'bg-emerald-500' : 'bg-brand-accent animate-pulse'}`}></div>
                                                <span className="text-sm font-black text-[#0F1E2E] tracking-tight">{juryScores.length > 0 ? 'Analyzed' : 'Evaluating'}</span>
                                            </div>
                                        </div>
                                        <div className="flex flex-col min-w-[120px]">
                                            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Overall Score</span>
                                            <span className="text-sm font-black text-[#0F1E2E] tracking-tight">{aiScores10.avg || "—"} / 10</span>
                                        </div>
                                        <div className="flex flex-col min-w-[100px]">
                                            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Risk Level</span>
                                            <span className={`text-sm font-black tracking-tight ${team.risk_level === 'High' ? 'text-rose-600' : team.risk_level === 'Low' ? 'text-emerald-600' : 'text-amber-600'}`}>
                                                {team.risk_level || 'Medium'}
                                            </span>
                                        </div>
                                    </div>
                                </div>

                                <div className="space-y-10">
                                    <CollapsibleSection title="Vision Statement" icon={<Sparkles size={24} />}>
                                        <Section
                                            title="The Problem"
                                            text={team.problem_statement}
                                            subHeader={team.problem_title}
                                            icon={<AlertTriangle size={18} />}
                                        />
                                        <Section
                                            title="The Solution"
                                            text={team.proposed_solution}
                                            icon={<Lightbulb size={18} />}
                                        />
                                    </CollapsibleSection>

                                    <CollapsibleSection title="Core Innovation" icon={<Rocket size={24} />}>
                                        <BulletRow
                                            title="Disruption Vectors"
                                            items={team.innovation_highlights}
                                            icon={<Zap size={18} />}
                                        />
                                        <ChipRow
                                            title="Technology Stack"
                                            items={team.tech_stack}
                                            variant="indigo"
                                            icon={<Settings size={18} />}
                                        />
                                    </CollapsibleSection>

                                    <CollapsibleSection title="Market Dynamics" icon={<TrendingUp size={24} />} defaultOpen={false}>
                                        <Section
                                            title="Market Insights"
                                            text={team.market_insight}
                                            icon={<Activity size={18} />}
                                        />
                                        <ChipRow
                                            title="Target Demographics"
                                            items={team.target_users}
                                            variant="teal"
                                            icon={<Target size={18} />}
                                        />
                                        <Section
                                            title="Business Architecture"
                                            text={team.business_model}
                                            icon={<ShieldCheck size={18} />}
                                        />
                                    </CollapsibleSection>

                                    <CollapsibleSection title="Readiness Profile" icon={<ShieldCheck size={24} />} defaultOpen={false}>
                                        <Section
                                            title="Market Maturity"
                                            text={team.market_readiness}
                                            icon={<Activity size={18} />}
                                        />
                                        <Section
                                            title="Execution Risk"
                                            text={team.execution_risk}
                                            icon={<AlertTriangle size={18} />}
                                        />
                                    </CollapsibleSection>
                                </div>
                            </div>
                        </div>

                        <div id="scoring" className="mt-20 scroll-mt-24 space-y-10 animate-advanced-reveal">
                            <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
                                <div className="flex-1">
                                    <h2 className="text-4xl font-black text-slate-900 tracking-tight italic uppercase">Jury Scoring Protocol</h2>
                                    <div className="flex flex-col md:flex-row items-start md:items-center gap-4 mt-2">
                                        <p className="text-slate-400 font-medium max-w-sm">Input your evaluation metrics using the precision sliders below.</p>
                                        <div className="flex-1 max-w-xs">
                                            <input
                                                type="text"
                                                value={juryName}
                                                onChange={(e) => setJuryName(e.target.value)}
                                                placeholder="Enter Jury Name (Required)"
                                                disabled={juryScores.length > 0}
                                                className="w-full bg-white border border-slate-200 rounded-lg px-4 py-2 text-sm font-bold placeholder:text-slate-300 focus:ring-4 focus:ring-brand-accent/10 outline-none transition-all"
                                            />
                                        </div>
                                    </div>

                                    {/* Smart Advisory Rules */}
                                    <div className="mt-6 space-y-2">
                                        {evaluationTime < 30 && evaluationTime > 5 && (
                                            <div className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-amber-600 bg-amber-50 px-3 py-1.5 rounded-lg w-fit border border-amber-100 animate-pulse">
                                                <TimerIcon size={12} />
                                                Accelerated Evaluation: Ensure thorough analysis
                                            </div>
                                        )}
                                        {alignment < 60 && (
                                            <div className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-rose-500 bg-rose-50 px-3 py-1.5 rounded-lg w-fit border border-rose-100 animate-premium">
                                                <AlertTriangle size={12} />
                                                High Deviation: Jury input varies significantly from AI benchmark
                                            </div>
                                        )}
                                    </div>
                                </div>
                                <div className="bg-[#F4F7FA] border border-[#0F1E2E]/10 px-8 py-6 rounded-[2rem] flex flex-col items-center min-w-[200px] shadow-sm relative group overflow-hidden">
                                    <div className="absolute inset-0 bg-brand-accent/5 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                                    <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1 relative z-10">Calculated Multi-Score</span>
                                    <div className="text-5xl font-black text-[#0F1E2E] tracking-tighter tabular-nums relative z-10">{weightedScore}</div>
                                </div>
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-8">
                                <ScoringSlider
                                    title="Desirability"
                                    icon={<Heart size={20} />}
                                    weight={0.3}
                                    value={jury.desirability}
                                    onChange={(v) => setJury(s => ({ ...s, desirability: v }))}
                                    disabled={juryScores.length > 0}
                                />
                                <ScoringSlider
                                    title="Feasibility"
                                    icon={<Settings size={20} />}
                                    weight={0.3}
                                    value={jury.feasibility}
                                    onChange={(v) => setJury(s => ({ ...s, feasibility: v }))}
                                    disabled={juryScores.length > 0}
                                />
                                <ScoringSlider
                                    title="Viability"
                                    icon={<Coins size={20} />}
                                    weight={0.3}
                                    value={jury.viability}
                                    onChange={(v) => setJury(s => ({ ...s, viability: v }))}
                                    disabled={juryScores.length > 0}
                                />
                                <ScoringSlider
                                    title="Presentation"
                                    icon={<Mic2 size={20} />}
                                    weight={0.1}
                                    value={jury.presentation}
                                    onChange={(v) => setJury(s => ({ ...s, presentation: v }))}
                                    disabled={juryScores.length > 0}
                                />
                            </div>

                            <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
                                <div className="lg:col-span-2 space-y-4">
                                    <label className="text-xs font-black uppercase text-slate-500 tracking-widest">Jury's Feedback (Auto-saved)</label>
                                    <textarea
                                        value={juryNotes}
                                        onChange={(e) => setJuryNotes(e.target.value)}
                                        placeholder="Executive insights based on jury presentation..."
                                        disabled={juryScores.length > 0}
                                        className="w-full h-48 bg-white border border-slate-200 rounded-xl p-8 text-slate-900 font-medium placeholder:text-slate-300 focus:ring-8 focus:ring-brand-accent/5 outline-none transition-all resize-none shadow-sm"
                                    />
                                </div>
                                <div className="space-y-6 flex flex-col justify-end">
                                    <div className="relative group">
                                        {juryScores.length > 0 ? (
                                            <div className="flex flex-col items-center gap-4 animate-premium">
                                                <div className="flex items-center justify-center bg-emerald-100 text-emerald-600 border border-emerald-200 rounded-2xl py-4 w-full max-w-[220px] mx-auto font-black uppercase italic tracking-[0.2em] shadow-lg shadow-emerald-500/10">
                                                    <CheckCircle2 size={16} className="mr-2" /> Submitted
                                                </div>
                                                <button
                                                    onClick={() => router.push('/')}
                                                    className="w-full max-w-[220px] mx-auto py-4 bg-slate-900 text-white rounded-2xl font-black uppercase italic tracking-widest hover:bg-slate-800 transition-all flex items-center justify-center"
                                                >
                                                    Back to Hub
                                                </button>
                                            </div>
                                        ) : (
                                            <button
                                                onClick={onSubmit}
                                                disabled={submitting}
                                                className="w-full max-w-[220px] mx-auto block py-4 bg-brand-accent text-white rounded-2xl font-black uppercase italic tracking-[0.2em] shadow-xl shadow-brand-accent/20 hover:scale-[1.02] hover:bg-slate-900 active:scale-[0.98] transition-all disabled:opacity-50 disabled:cursor-not-allowed group"
                                            >
                                                {submitting ? 'Submitting...' : 'Submit'}
                                            </button>
                                        )}
                                    </div>
                                </div>
                            </div>

                            {error && (
                                <div className="bg-rose-50 border border-rose-200 text-rose-600 p-6 rounded-3xl font-bold flex items-center gap-4 animate-premium">
                                    <XCircle size={24} />
                                    {error}
                                </div>
                            )}
                        </div>
                    </div>
                )}
            </main>
        </div>
    );
}
